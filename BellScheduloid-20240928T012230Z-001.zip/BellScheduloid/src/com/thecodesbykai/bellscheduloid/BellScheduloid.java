package com.thecodesbykai.bellscheduloid;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.TextView;
import android.widget.Spinner;

public class BellScheduloid extends Activity implements OnItemSelectedListener {
	private Handler mHandler = new Handler();
	private final int REFRESH_RATE = 100;
	static Date NextBell;
	static int BellID;
	static String Class;
	static String disptime; static Date systime;
	static String[][] BellSchedule = new String[11][4];
	static String selected;
	static int ArrayLBound_x; static int ArrayLBound_y;
	static int ArrayUBound_x; static int ArrayUBound_y;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        ((Spinner)findViewById(R.id.Schedule)).setOnItemSelectedListener(this);
		selected = "Standard";GetBellSchedule();
		Timer_Resume();
    }
    @Override public void onPause() { super.onPause(); Timer_Pause(); }
    @Override public void onResume() { super.onResume(); Gui_MainMenu(null); }
	public void Time() {
		disptime = (new SimpleDateFormat("hh:mm:ss a")).format((Calendar.getInstance()).getTime());
		systime = String2Time((new SimpleDateFormat("HH:mm:ss")).format((Calendar.getInstance()).getTime()));
		//systime = String2Time("10:20:00");
	}
	public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {selected = parent.getItemAtPosition(pos).toString();GetBellSchedule();}
	public void onNothingSelected(AdapterView<?> parent) {selected = "Standard";GetBellSchedule();}
	public Date String2Time(String date) {
		try {
			return (new SimpleDateFormat("HH:mm:ss")).parse(date);
		} catch (ParseException e) { e.printStackTrace(); return null;}
	}
	
	public void GetBellID() {
		Time();
		ArrayLBound_x=0; ArrayLBound_y=0;ArrayUBound_x=0; ArrayUBound_y=0;
		for(int x=0; x<BellSchedule.length; x++){ for(int y=1; y<4; y++){ if (BellSchedule[x][y] != null) {
			if (systime.after(String2Time(BellSchedule[x][y]))) {
				if ((ArrayLBound_x==0 && ArrayLBound_y==0)||(String2Time(BellSchedule[ArrayLBound_x][ArrayLBound_y]).before(String2Time(BellSchedule[x][y])))) {
					ArrayLBound_x=x; ArrayLBound_y=y;
				}
			} //else 
			if (systime.before(String2Time(BellSchedule[x][y]))) {
				if ((ArrayUBound_x==0 && ArrayUBound_y==0)||(String2Time(BellSchedule[ArrayUBound_x][ArrayUBound_y]).after(String2Time(BellSchedule[x][y])))) {
					ArrayUBound_x=x; ArrayUBound_y=y;
				}
			}
		}}}
		if (ArrayUBound_y==0) {
			ArrayUBound_x=1; ArrayUBound_y=1;
		}
		if (ArrayLBound_y==0) {
			for(int x=0; x<BellSchedule.length; x++){ if (BellSchedule[x][1] != null) {
				ArrayLBound_x=x; ArrayLBound_y=2;
			}}
		}
		if (BellSchedule[ArrayLBound_x][0]==BellSchedule[ArrayUBound_x][0]) {
			Class = BellSchedule[ArrayLBound_x][0];
		} else {
			Class = BellSchedule[ArrayLBound_x][0]+" - "+BellSchedule[ArrayUBound_x][0];
		}
	}
	private Runnable startTimer = new Runnable() { public void run() {
			Output();
			mHandler.postDelayed(this,REFRESH_RATE);
	}};
	public void Output() {
		GetBellID();
		((TextView)findViewById(R.id.Time)).setText(disptime);
		((TextView)findViewById(R.id.CurrentBell)).setText(Class);
		long diff = (String2Time(BellSchedule[ArrayUBound_x][ArrayUBound_y]).getTime() - systime.getTime());
		if (diff < 0) { diff += 86400000;}
		String d = String.valueOf(diff / 86400000);
		String h = String.valueOf(diff % 86400000 / 3600000); if (h.length() < 2) { h = "0" + h;}
		String m = String.valueOf(diff % 86400000 % 3600000 / 60000); if (m.length() < 2) { m = "0" + m;}
		String s = String.valueOf(diff % 86400000 % 3600000 % 60000 / 1000); if (s.length() < 2) { s = "0" + s;}
		((TextView)findViewById(R.id.Countdown)).setText(d+"days "+h+"hrs "+m+"min "+s+"sec");
	}
	public void GetBellSchedule() {
		for(int x=0; x<BellSchedule.length; x++){ for(int y=0; y<4; y++){BellSchedule[x][y] = null;}}
		//((TextView)findViewById(R.id.textView2)).setText(selected);
		if (selected.contains("Standard")) {
			BellSchedule[1][0] = "Period 1";
			BellSchedule[1][1] = "07:35:00";
			BellSchedule[1][2] = "08:28:00";
			BellSchedule[2][0] = "Period 2";
			BellSchedule[2][1] = "08:34:00";
			BellSchedule[2][2] = "09:27:00";
			BellSchedule[3][0] = "Period 3";
			BellSchedule[3][1] = "09:33:00";
			BellSchedule[3][2] = "10:31:00";
			BellSchedule[4][0] = "First Lunch";
			BellSchedule[4][1] = "10:37:00";
			BellSchedule[4][2] = "11:07:00";
			BellSchedule[5][0] = "Period 4";
			BellSchedule[5][1] = "11:14:00";
			BellSchedule[5][2] = "12:07:00";
			BellSchedule[6][0] = "Period 5";
			BellSchedule[6][1] = "12:13:00";
			BellSchedule[6][2] = "13:06:00";
			BellSchedule[7][0] = "Period 6";
			BellSchedule[7][1] = "13:12:00";
			BellSchedule[7][2] = "14:05:00";
		} if (selected.contains("TigerPride18min")) {
			BellSchedule[1][0] = "Period 1";
			BellSchedule[1][1] = "07:35:00";
			BellSchedule[1][2] = "08:25:00";
			BellSchedule[2][0] = "Period 2";
			BellSchedule[2][1] = "08:30:00";
			BellSchedule[2][2] = "09:20:00";
			BellSchedule[3][0] = "Period 3";
			BellSchedule[3][1] = "09:25:00";
			BellSchedule[3][2] = "10:19:00";
			BellSchedule[4][0] = "Tiger Pride";
			BellSchedule[4][1] = "10:24:00";
			BellSchedule[4][2] = "10:42:00";
			BellSchedule[5][0] = "First Lunch";
			BellSchedule[5][1] = "10:42:00";
			BellSchedule[5][2] = "11:20:00";
			BellSchedule[6][0] = "Period 4";
			BellSchedule[6][1] = "11:25:00";
			BellSchedule[6][2] = "12:15:00";
			BellSchedule[7][0] = "Period 5";
			BellSchedule[7][1] = "12:20:00";
			BellSchedule[7][2] = "13:10:00";
			BellSchedule[8][0] = "Period 6";
			BellSchedule[8][1] = "13:15:00";
			BellSchedule[8][2] = "14:05:00";
		} if (selected.contains("TigerPride25min")) {
			BellSchedule[1][0] = "Period 1";
			BellSchedule[1][1] = "07:35:00";
			BellSchedule[1][2] = "08:25:00";
			BellSchedule[2][0] = "Period 2";
			BellSchedule[2][1] = "08:30:00";
			BellSchedule[2][2] = "09:20:00";
			BellSchedule[3][0] = "Period 3";
			BellSchedule[3][1] = "09:25:00";
			BellSchedule[3][2] = "10:15:00";
			BellSchedule[4][0] = "Tiger Pride";
			BellSchedule[4][1] = "10:20:00";
			BellSchedule[4][2] = "10:45:00";
			BellSchedule[5][0] = "First Lunch";
			BellSchedule[5][1] = "10:45:00";
			BellSchedule[5][2] = "11:23:00";
			BellSchedule[6][0] = "Period 4";
			BellSchedule[6][1] = "11:28:00";
			BellSchedule[6][2] = "12:18:00";
			BellSchedule[7][0] = "Period 5";
			BellSchedule[7][1] = "12:13:00";
			BellSchedule[7][2] = "13:13:00";
			BellSchedule[8][0] = "Period 6";
			BellSchedule[8][1] = "13:18:00";
			BellSchedule[8][2] = "14:05:00";
		} if (selected.contains("TigerPride36min")) {
			BellSchedule[1][0] = "Period 1";
			BellSchedule[1][1] = "07:35:00";
			BellSchedule[1][2] = "08:23:00";
			BellSchedule[2][0] = "Period 2";
			BellSchedule[2][1] = "08:28:00";
			BellSchedule[2][2] = "09:16:00";
			BellSchedule[3][0] = "Period 3";
			BellSchedule[3][1] = "09:21:00";
			BellSchedule[3][2] = "10:09:00";
			BellSchedule[4][0] = "Tiger Pride";
			BellSchedule[4][1] = "10:14:00";
			BellSchedule[4][2] = "10:50:00";
			BellSchedule[5][0] = "First Lunch";
			BellSchedule[5][1] = "10:50:00";
			BellSchedule[5][2] = "11:28:00";
			BellSchedule[6][0] = "Period 4";
			BellSchedule[6][1] = "11:33:00";
			BellSchedule[6][2] = "12:21:00";
			BellSchedule[7][0] = "Period 5";
			BellSchedule[7][1] = "12:26:00";
			BellSchedule[7][2] = "13:14:00";
			BellSchedule[8][0] = "Period 6";
			BellSchedule[8][1] = "13:19:00";
			BellSchedule[8][2] = "14:05:00";
		} if (selected.contains("ThirdPeriodAssembly")) {
			BellSchedule[1][0] = "Period 1";
			BellSchedule[1][1] = "07:35:00";
			BellSchedule[1][2] = "08:18:00";
			BellSchedule[2][0] = "Period 2";
			BellSchedule[2][1] = "08:24:00";
			BellSchedule[2][2] = "09:07:00";
			BellSchedule[3][0] = "Period 3";
			BellSchedule[3][1] = "09:13:00";
			BellSchedule[3][2] = "09:55:59";
			BellSchedule[4][0] = "Announcements & Dismissal";
			BellSchedule[4][1] = "09:56:00";
			BellSchedule[4][2] = "10:15:59";
			BellSchedule[5][0] = "Assembly";
			BellSchedule[5][1] = "10:16:00";
			BellSchedule[5][2] = "11:02:00";
			BellSchedule[6][0] = "First Lunch";
			BellSchedule[6][1] = "11:08:00";
			BellSchedule[6][2] = "11:38:00";
			BellSchedule[7][0] = "Period 4";
			BellSchedule[7][1] = "11:44:00";
			BellSchedule[7][2] = "12:27:00";
			BellSchedule[8][0] = "Period 5";
			BellSchedule[8][1] = "12:33:00";
			BellSchedule[8][2] = "13:16:00";
			BellSchedule[9][0] = "Period 6";
			BellSchedule[9][1] = "13:22:00";
			BellSchedule[9][2] = "14:05:00";
		} if (selected.contains("SixthPeriodAssembly")) {
			BellSchedule[1][0] = "Period 1";
			BellSchedule[1][1] = "07:35:00";
			BellSchedule[1][2] = "08:18:00";
			BellSchedule[2][0] = "Period 2";
			BellSchedule[2][1] = "08:24:00";
			BellSchedule[2][2] = "09:07:00";
			BellSchedule[3][0] = "Period 3";
			BellSchedule[3][1] = "09:13:00";
			BellSchedule[3][2] = "09:56:00";
			BellSchedule[4][0] = "First Lunch";
			BellSchedule[4][1] = "10:02:00";
			BellSchedule[4][2] = "10:32:00";
			BellSchedule[5][0] = "Period 4";
			BellSchedule[5][1] = "10:38:00";
			BellSchedule[5][2] = "11:21:00";
			BellSchedule[6][0] = "Period 5";
			BellSchedule[6][1] = "11:27:00";
			BellSchedule[6][2] = "12:10:00";
			BellSchedule[7][0] = "Period 6";
			BellSchedule[7][1] = "12:16:00";
			BellSchedule[7][2] = "12:58:99";
			BellSchedule[8][0] = "Announcements";
			BellSchedule[8][1] = "12:59:00";
			BellSchedule[8][2] = "13:04:59";
			BellSchedule[9][0] = "Dismissal";
			BellSchedule[9][1] = "13:05:00";
			BellSchedule[9][2] = "13:10:00";
			BellSchedule[10][0] = "Assembly";
			BellSchedule[10][1] = "13:15:00";
			BellSchedule[10][2] = "14:05:00";
		}
	}
	public void Timer_Pause() { mHandler.removeCallbacks(startTimer); }
	public void Timer_Resume() { mHandler.removeCallbacks(startTimer); mHandler.postDelayed(startTimer, 0); }
	public void Gui_AboutMenu(View view) {
		Timer_Pause(); setContentView(R.layout.about);
	}
	public void Gui_MainMenu(View view) {
		Timer_Resume(); setContentView(R.layout.main);
	}
}