package com.thecodesbykai.bellscheduloid;

import java.util.ArrayList;

import com.thecodesbykai.bellscheduloid.FileOperations.Standard_Paths;
import com.thecodesbykai.bellscheduloid.XML_Schedules.Schedule;
import com.thecodesbykai.bellscheduloid.XML_Schedules.Schedule.Classes;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TableRow.LayoutParams;
import android.widget.TextView;

public class GUI_All_Classes extends Activity {
	static Data_Schedules data_Schedules;
	static int selected_Schedule;
	static Spinner spinner_Schedule;
	static Handler mHandler = new Handler();
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.view_all_classes);
		
	}

	@Override
	public void onPause() {
		super.onPause();
		mHandler.removeCallbacks(Refresh);
	}
	@Override
	public void onResume() {
		super.onResume();
		TableLayout tableLayout_All_CLasses = (TableLayout)findViewById(R.id.TableLayout01);
		
		FileOperations fileOperations = new FileOperations(this);
		XML_Schedules XML_SCHEDULES = new XML_Schedules(fileOperations.getFileInputStream_ESD(Standard_Paths.MY_APPLICATION_DATA_DIRECTORY + "/BellScheduloid/BellScheduloid.xml"));
		Schedule XML_SCHEDULE = XML_SCHEDULES.new Schedule(GUI_BellView.data_Schedules.get().get(GUI_BellView.selected_Schedule));
		Classes XML_CLASSES = XML_SCHEDULE.new Classes();
		ArrayList<ArrayList<String>> classes = XML_CLASSES.get();
        
		tableLayout_All_CLasses.removeAllViews();
        TableRow tr = new TableRow(this);
        tr.setId(0);
        tr.setLayoutParams(new LayoutParams(
                LayoutParams.FILL_PARENT,
                LayoutParams.WRAP_CONTENT));   
        tr.addView(new TL_TextView(Color.RED, 000, "Class Name\t").get());
        tr.addView(new TL_TextView(Color.RED, 100, "Time Begin\t").get());
        tr.addView(new TL_TextView(Color.RED, 200, "Time Ends\t").get());
        tableLayout_All_CLasses.addView(tr, new TableLayout.LayoutParams(
                LayoutParams.FILL_PARENT,
                LayoutParams.WRAP_CONTENT));
        
		for (int index = 0; index <= classes.size() - 1; index++) {
        // Create a TableRow and give it an ID
        tr = new TableRow(this);
        tr.setId(index + 1);
        tr.setLayoutParams(new LayoutParams(
                LayoutParams.FILL_PARENT,
                LayoutParams.WRAP_CONTENT));   
        tr.addView(new TL_TextView(Color.WHITE, 100 + index, classes.get(index).get(0) + "\t").get());
        tr.addView(new TL_TextView(Color.WHITE, 200 + index, classes.get(index).get(1) + "\t").get());
        tr.addView(new TL_TextView(Color.WHITE, 300 + index, classes.get(index).get(2) + "\t").get());        
        // Add the TableRow to the TableLayout
        tableLayout_All_CLasses.addView(tr, new TableLayout.LayoutParams(
                LayoutParams.FILL_PARENT,
                LayoutParams.WRAP_CONTENT));
		}
		new Views(this).new Button_About();
		mHandler.removeCallbacks(Refresh);
		mHandler.postDelayed(Refresh, 0);
	}
	private Runnable Refresh = new Runnable() {
		private static final int REFRESH_RATE = 100;

		public void run() {
			new Views(GUI_All_Classes.this).new TextView_Time();
			mHandler.postDelayed(this, REFRESH_RATE);
		}
	};
	class TL_TextView {
		TextView MY_TEXT_VIEW = new TextView(GUI_All_Classes.this);
		TL_TextView(int color, int id, String tV_Content) {
	        MY_TEXT_VIEW.setId(id);
	        	MY_TEXT_VIEW.setText(tV_Content);
	        MY_TEXT_VIEW.setTextColor(color);
	        MY_TEXT_VIEW.setLayoutParams(new LayoutParams(
	                LayoutParams.FILL_PARENT,
	                LayoutParams.WRAP_CONTENT));
		}
		TextView get() {
			return MY_TEXT_VIEW;
		}
	}


}
