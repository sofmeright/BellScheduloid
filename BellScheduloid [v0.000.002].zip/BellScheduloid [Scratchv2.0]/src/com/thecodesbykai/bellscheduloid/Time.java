package com.thecodesbykai.bellscheduloid;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Time {
	int nDay;
	int nMonth;
	int nYear;
	String AM_PM;

	public String getString() {
		SimpleDateFormat sdf = new SimpleDateFormat("E - MM/dd/yyyy - hh:mm:ss a");
		Date d = Calendar.getInstance().getTime();
		return sdf.format(d);
	}
	
	public String get24HString() {
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		Date d = Calendar.getInstance().getTime();
		return sdf.format(d);
	}

	public Date get() {
		Date d = Calendar.getInstance().getTime();
		return d;
	}
	
	String getDifference(Date d1, Date d2) {
		long diff = d2.getTime() - d1.getTime();
		if (diff < 0) { diff += 86400000;}
		String d = String.valueOf(diff / 86400000);
		String h = String.valueOf(diff % 86400000 / 3600000); if (h.length() < 2) { h = "0" + h;}
		String m = String.valueOf(diff % 86400000 % 3600000 / 60000); if (m.length() < 2) { m = "0" + m;}
		String s = String.valueOf(diff % 86400000 % 3600000 % 60000 / 1000); if (s.length() < 2) { s = "0" + s;}
		return d+"days "+h+"hrs "+m+"min "+s+"sec";
	}
}
