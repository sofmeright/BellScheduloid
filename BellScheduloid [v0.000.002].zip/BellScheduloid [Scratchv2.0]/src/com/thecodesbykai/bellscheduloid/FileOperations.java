package com.thecodesbykai.bellscheduloid;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import android.content.Context;
import android.content.res.AssetManager;
import android.os.Environment;

class FileOperations {
	private final Context context;

	FileOperations(Context c) {
		this.context = c;
	}

	boolean moveAssetToSD(String assetFileName, String dest_path) {
		AssetManager am = context.getAssets();
		try {
			InputStream is = am.open(assetFileName);
			File dir = new File(Standard_Paths.EXTERNAL_STORAGE_DIRECTORY + dest_path);
			dir.mkdirs();
			File file = new File(dir, assetFileName);
			if (file.exists()) {
				return true;
			} else {
				OutputStream os = new FileOutputStream(file);
				byte[] buffer = new byte[1024];
				int read;
				while ((read = is.read(buffer)) != -1) {
					os.write(buffer, 0, read);
				}
				is.close();
				is = null;
				os.flush();
				os.close();
				os = null;
				return true;
			}
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}
	FileInputStream getFileInputStream_ESD(String filePath) {
		try {
			return new FileInputStream(filePath);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
	static class Standard_Paths {
		static String EXTERNAL_STORAGE_DIRECTORY = Environment.getExternalStorageDirectory().getAbsolutePath();
		static String APPLICATION_DATA_DIRECTORY = EXTERNAL_STORAGE_DIRECTORY + "/Android/data";
		static String MY_APPLICATION_DATA_DIRECTORY = APPLICATION_DATA_DIRECTORY + "/com.thecodesbykai";
	}
	
}