package com.thecodesbykai.bellscheduloid;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

public class XML_Schedules {
	private static InputStream inputStream;
	XML_Schedules(InputStream iS) {
		inputStream = iS;
	}
	public class Schedule {
		String scheduleName;
		Schedule(String scheduleName) {
			this.scheduleName = scheduleName;
		}
		public ArrayList<String> CheckSchedule(Date d, ArrayList<ArrayList<String>> schedules) {
			ArrayList<String> a = new ArrayList<String>();
			ArrayList<String> b = new ArrayList<String>();
			ArrayList<String> Event = new ArrayList<String>();
			//Classes objClasses = new Classes();
			ArrayList<ArrayList<String>> Schedules = new ArrayList<ArrayList<String>>();
			Schedules = schedules;
			Calendar time = Calendar.getInstance();
			time.setTime(d);
			int checkday = -1;
			while (a.size() <= 0 || b.size() <= 0) {
				for (Integer ci = 0; ci < Schedules.size(); ci++) {
					for (Integer i = 1; i <= 2; i++) {
						try {
							SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
							Date date = (Date)sdf.parse(Schedules.get(ci).get(i));
							Calendar cal = Calendar.getInstance();
							cal.setTime(date);
							cal.set(time.get(Calendar.YEAR), time.get(Calendar.MONTH), time.get(Calendar.DATE));
							cal.add(Calendar.DAY_OF_MONTH, checkday);
							boolean TIME_IS_AFTER_EVENT_BEGINS = cal.compareTo(time) <= 0;
							boolean TIME_IS_BEFORE_EVENT_ENDS = cal.compareTo(time) > 0;
							ArrayList<String> looparray = new ArrayList<String>();
							looparray.add(Schedules.get(ci).get(0));
							looparray.add(new SimpleDateFormat("E - MM/dd/yyyy - hh:mm:ss a").format(cal.getTime()));
							if (TIME_IS_AFTER_EVENT_BEGINS) {
								a = looparray;
							} if (b.size() <= 0) {
								if (TIME_IS_BEFORE_EVENT_ENDS) {
									b = looparray;
								}
							}
						} catch (ParseException e) {
						}
					}
				}
				checkday++;
			}
			if (a.size() > 0 && b.size() > 0) {
				Event.add(a.get(0) + " - " + b.get(0));
				Event.add(a.get(1));
				Event.add(b.get(1));
			} else if (a.size() > 0) {
				Event.add(a.get(0) + " - ??????");
				Event.add(a.get(1));
				Event.add("??:??:??");
			} else if (b.size() > 0) {
				Event.add("?????? - " + b.get(0));
				Event.add("??:??:??");
				Event.add(b.get(1));
			}
			return Event;
		}

		public class Classes {
			public ArrayList<ArrayList<String>> get() {
				ArrayList<ArrayList<String>> classes = new ArrayList<ArrayList<String>>();
				try {
					boolean inTargetedTag = false;
					XmlPullParser parser = XmlPullParserFactory.newInstance().newPullParser();
					parser.setInput(inputStream, null);
					int eventType = parser.getEventType();
					while (eventType != XmlPullParser.END_DOCUMENT) {
						switch (eventType) {
						case XmlPullParser.START_TAG:
							String tagName = parser.getName();
							if (tagName.equalsIgnoreCase("Schedule")) {
								if (parser.getAttributeValue(null, "Name").equals(scheduleName)) {
									inTargetedTag = true;
								} else {
									inTargetedTag = false;
								}
							} if (tagName.equalsIgnoreCase("Class")) {
								if (inTargetedTag) {
									ArrayList<String> single_Class = new ArrayList<String>();
									single_Class.add(parser.getAttributeValue(null, "Name"));
									single_Class.add(parser.getAttributeValue(null, "Start"));
									single_Class.add(parser.getAttributeValue(null, "End"));
									classes.add(single_Class);
								}
							}
							break;
						}
						eventType = parser.next();
					}
				} catch (FileNotFoundException e) {
				} catch (IOException e) {
				} catch (Exception e) {
				}
				return classes;
			}
		}

	}
	class List {
		ArrayList<String> schedules = new ArrayList<String>();
		List() {
			try {
				XmlPullParser parser = XmlPullParserFactory.newInstance().newPullParser();
				parser.setInput(inputStream, null);
				int eventType = parser.getEventType();
				while (eventType != XmlPullParser.END_DOCUMENT) {
					switch (eventType) {
					case XmlPullParser.START_TAG:
						String tagName = parser.getName();
						if (tagName.equalsIgnoreCase("Schedule")) {
							schedules.add(parser.getAttributeValue(null, "Name"));
						}
						break;
					}
					eventType = parser.next();
				}
			} catch (FileNotFoundException e) {
			} catch (IOException e) {
			} catch (Exception e) {
			}
		}
		ArrayList<String> get() {
			return schedules;
		}
	}
}
