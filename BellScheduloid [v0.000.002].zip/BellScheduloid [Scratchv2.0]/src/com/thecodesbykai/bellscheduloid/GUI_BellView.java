package com.thecodesbykai.bellscheduloid;

import java.io.InputStream;

import com.thecodesbykai.bellscheduloid.FileOperations.Standard_Paths;
import com.thecodesbykai.bellscheduloid.XML_Schedules.List;
import com.thecodesbykai.bellscheduloid.XML_Edit;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Spinner;
import android.widget.TextView;

public class GUI_BellView extends Activity {
	static Data_Schedules data_Schedules;
	static int selected_Schedule;
	static Spinner spinner_Schedule; static TextView tV_ClassName;
	static InputStream is;
	static Handler mHandler = new Handler();
	static FileOperations fileOperations;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		fileOperations = new FileOperations(this);
		fileOperations.moveAssetToSD("BellScheduloid.xml", "/Android/data/com.thecodesbykai/BellScheduloid");
	}

	@Override
	public void onPause() {
		super.onPause();
		mHandler.removeCallbacks(Refresh);
	}
	@Override
	public void onResume() {
		super.onResume();
		setContentView(R.layout.main);
		fileOperations = new FileOperations(this);
		XML_Schedules XML_SCHEDULES = new XML_Schedules(fileOperations.getFileInputStream_ESD(Standard_Paths.MY_APPLICATION_DATA_DIRECTORY + "/BellScheduloid/BellScheduloid.xml"));
		List list = XML_SCHEDULES.new List();
		data_Schedules = new Data_Schedules(list.get());
		new Views(this).new Spinner_Schedules();
		new Views(this).new Button_About();
		new Views(this).new Button_ViewAllClasses();
		new XML_Edit(Standard_Paths.MY_APPLICATION_DATA_DIRECTORY + "/BellScheduloid/BellScheduloid.xml").new Schedule("Standard").setName("BlahbSchedule");
		
		mHandler.removeCallbacks(Refresh);
		mHandler.postDelayed(Refresh, 0);
	}

	private Runnable Refresh = new Runnable() {
		private static final int REFRESH_RATE = 100;

		public void run() {
			new Views(GUI_BellView.this).new TextView_Time();
			new Views(GUI_BellView.this).new TextView_ClassName();
			new Views(GUI_BellView.this).new TextView_CountDown();
			//TV_ClassName.setText(objClasses.get("Standard").get(0).get(0));
			//ArrayList<String> Event = BellScheduloid_XML.CheckSchedule(Time.getString());
			//
			//TV_ClassName.setText(BellScheduloid_XML.Classes.get("Standard")[0][0]);
			mHandler.postDelayed(this, REFRESH_RATE);
		}
	};

}
