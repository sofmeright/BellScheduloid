package com.thecodesbykai.bellscheduloid;

import java.util.ArrayList;
import java.util.Date;

public class Data_Schedules {
	static ArrayList<String> schedule_List = new ArrayList<String>();
	Data_Schedules(ArrayList<String> sL) { 
		schedule_List = sL;
	}
	ArrayList<String> get() {
		return schedule_List;
	}
	
	static class Schedule {
		static String scheduleName;
		Schedule(String scheduleName) {
			Schedule.scheduleName = scheduleName;
		}
		
		static class Classes {
			private final int CLASS_NAME		 = 0;
			private final int CLASS_DATE_BEGIN	 = 1;
			private final int CLASS_DATE_END	 = 2;
			static ArrayList<ArrayList<Object>> classes;
			Classes() { 
				classes = new ArrayList<ArrayList<Object>>();
			}
			
			void add(String className, Date timeBegin, Date timeEnd) {
				ArrayList<Object> Class = new ArrayList<Object>();
				Class.add(CLASS_NAME, className);
				Class.add(CLASS_DATE_BEGIN, className);
				Class.add(CLASS_DATE_END, className);
				classes.add(Class);
			}
			Object get(int index) {
				return classes.get(index);
			}
		}
	}
	
}
