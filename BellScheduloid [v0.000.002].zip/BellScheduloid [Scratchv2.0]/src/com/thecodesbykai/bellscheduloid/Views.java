package com.thecodesbykai.bellscheduloid;

import java.io.FileInputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import com.thecodesbykai.bellscheduloid.FileOperations.Standard_Paths;
import com.thecodesbykai.bellscheduloid.XML_Schedules.Schedule;
import com.thecodesbykai.bellscheduloid.XML_Schedules.Schedule.Classes;

class Views {
	/**
	 * 
	 */
	private final Activity activity;
	/**
	 * @param activity
	 */
	Views(Activity a) {
		this.activity = a;
	}
	
	class Button_About {
		final Button spinner_Schedule = (Button)activity.findViewById(R.id.main_button_about);
		Button_About() {
			spinner_Schedule.setClickable(true);
			spinner_Schedule.setOnClickListener(new View.OnClickListener() {
			    public void onClick(View v) {
					Intent myIntent = new Intent(activity, GUI_About.class);
					activity.startActivity(myIntent);
			    }
			  });
		}
	}
	class Button_ViewAllClasses {
		final Button button_ViewAllClasses = (Button)activity.findViewById(R.id.button_view_all_classes);
		Button_ViewAllClasses() {
			button_ViewAllClasses.setClickable(true);
			button_ViewAllClasses.setOnClickListener(new View.OnClickListener() {
			    public void onClick(View v) {
					Intent myIntent = new Intent(activity, GUI_All_Classes.class);
					activity.startActivity(myIntent);
			    }
			  });
		}
	}
	class Spinner_Schedules {
		final Spinner spinner_Schedule = (Spinner)activity.findViewById(R.id.Schedule);
		Spinner_Schedules() {
			ArrayAdapter<String> mAdapter;
			mAdapter = new ArrayAdapter<String>(activity,
					android.R.layout.simple_spinner_item, GUI_BellView.data_Schedules.get());
			mAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinner_Schedule.setAdapter(mAdapter);
			spinner_Schedule.setSelection(activity.getSharedPreferences(null, 0).getInt("Pos:Spinner_Schedules", 0));
			spinner_Schedule.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
				public void onItemSelected(AdapterView<?> parent, View v, int pos,
						long row) {
					GUI_BellView.selected_Schedule = pos;
					SharedPreferences.Editor ed = activity.getSharedPreferences(null, 0).edit();
					ed.putInt("Pos:Spinner_Schedules", pos);
					ed.commit();
				}
				public void onNothingSelected(AdapterView<?> parent) {
				}
			});
		}
	}
	class TextView_ClassName {
		TextView_ClassName() {
			TextView textView_ClassName = (TextView)activity.findViewById(R.id.CurrentBell);
			FileOperations fileOps = new FileOperations(activity);
			FileInputStream fis = fileOps.getFileInputStream_ESD(Standard_Paths.MY_APPLICATION_DATA_DIRECTORY + "/BellScheduloid/BellScheduloid.xml");
			XML_Schedules objXML = new XML_Schedules(fis);
			Schedule objSchedule = objXML.new Schedule(GUI_BellView.data_Schedules.get().get(GUI_BellView.selected_Schedule));
			Classes objClasses = objSchedule.new Classes();
			ArrayList<String> event = objSchedule.CheckSchedule(new Time().get(), objClasses.get());
			textView_ClassName.setText(event.get(0) + "\n" + event.get(1) + "\n" + event.get(2));
			//textView_ClassName.setText(objClasses.get().get(0).get(0));
		}
	}
	class TextView_CountDown {
		final TextView textView_CountDown = (TextView)activity.findViewById(R.id.Countdown);
		TextView_CountDown() {
			FileOperations fileOps = new FileOperations(activity);
			FileInputStream fis = fileOps.getFileInputStream_ESD(Standard_Paths.MY_APPLICATION_DATA_DIRECTORY + "/BellScheduloid/BellScheduloid.xml");
			XML_Schedules objXML = new XML_Schedules(fis);
			Schedule objSchedule = objXML.new Schedule(GUI_BellView.data_Schedules.get().get(GUI_BellView.selected_Schedule));
			Classes objClasses = objSchedule.new Classes();
			ArrayList<String> event = objSchedule.CheckSchedule(new Time().get(), objClasses.get());
			try {
				textView_CountDown.setText(new Time().getDifference(new Time().get(), new SimpleDateFormat("E - MM/dd/yyyy - hh:mm:ss a").parse(event.get(2)) ));
			} catch (ParseException e) {
			}
		}
	}
	class TextView_Time {
		final TextView textView_Time = (TextView)activity.findViewById(R.id.Time);
		TextView_Time() {
			textView_Time.setText(new Time().getString());
		}
	}
	//Toast toast = Toast.makeText(activity, "You clicked - uses an anonymouse inner class", Toast.LENGTH_SHORT);
	//toast.show();
	
}