package com.thecodesbykai.bellscheduloid;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class BellScheduloid extends Activity {

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		
		
		// attachOnItemSelectedListener();
	}

	@Override
	public void onPause() {
		super.onPause();
	}

	@Override
	public void onResume() {
		super.onResume();
		BellScheduloid CurrentActivity = BellScheduloid.this;
		Intent myIntent = new Intent(CurrentActivity, GUI_BellView.class);
		CurrentActivity.startActivity(myIntent);
		// ((Spinner)findViewById(R.id.Schedule)).setOnItemSelectedListener(new
		// myOnItemSelectedListener());
	}

	
	public void LoadGui() {
	}

}
