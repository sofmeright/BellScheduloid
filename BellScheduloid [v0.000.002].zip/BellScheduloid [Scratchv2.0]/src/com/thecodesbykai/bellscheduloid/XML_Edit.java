package com.thecodesbykai.bellscheduloid;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

public class XML_Edit {
	private static String filepath;
	
	String schedule_Name = new String();
	String class_Name = new String();

	XML_Edit(String fp) {
		filepath = fp;
	}

	class Schedule {

		Schedule(String Name) {
			schedule_Name = Name;
		}

		void setName(String new_Name) {
			try {
				DocumentBuilderFactory docFactory = DocumentBuilderFactory
						.newInstance();
				DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
				Document doc = docBuilder.parse(filepath);
				
				Node a_schedule;

				// Get the root element

				// Get the staff element , it may not working if tag has spaces,
				// or
				// whatever weird characters in front...it's better to use
				// getElementsByTagName() to get it directly.
				// Node company = doc.getFirstChild();
				// Node staff = company.getFirstChild();

				// Get the staff element by tag name directly
		
				a_schedule = doc.getElementsByTagName("Schedule").item(0);
				NamedNodeMap attributes = a_schedule.getAttributes();
				Node nodeAttr = attributes.getNamedItem("Name");
				nodeAttr.setTextContent(new_Name);
				// write the content into xml file
				TransformerFactory transformerFactory = TransformerFactory
						.newInstance();
				Transformer transformer = transformerFactory.newTransformer();
				DOMSource source = new DOMSource(doc);
				StreamResult result = new StreamResult(new File(filepath));
				transformer.transform(source, result);

				System.out.println("Done");

			} catch (ParserConfigurationException pce) {
				pce.printStackTrace();
			} catch (TransformerException tfe) {
				tfe.printStackTrace();
			} catch (IOException ioe) {
				ioe.printStackTrace();
			} catch (SAXException sae) {
				sae.printStackTrace();
			}

			schedule_Name = new_Name;
		}

		class Class {

			Class(String Name) {
				class_Name = Name;
			}

			void setName(String new_Name) {
				class_Name = new_Name;
			}

			void setTimeBegin() {

			}

			void setTimeEnd() {

			}
		}
	}
}
