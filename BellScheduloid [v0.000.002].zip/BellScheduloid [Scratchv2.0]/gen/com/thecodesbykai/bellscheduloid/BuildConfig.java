/** Automatically generated file. DO NOT MODIFY */
package com.thecodesbykai.bellscheduloid;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}