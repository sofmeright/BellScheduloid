function parseDateString(date)
{
	// YYYY-MM-DDTHH:mm:ss.sssZ
	// January 26, 2011 13:51:50
	var d = Date.parse('');
}