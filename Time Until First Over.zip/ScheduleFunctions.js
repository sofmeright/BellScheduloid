xml = loadXMLDoc("Schedules.xml");
schedulesList = xml.getElementsByTagName("Schedules")[0];
	
function loadXMLDoc(dname)
{
	if (window.XMLHttpRequest)
	{
		xhttp = new XMLHttpRequest();
	}
	else
	{
		xhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xhttp.open("GET", dname, false);
	xhttp.send();
	return xhttp.responseXML;
}

function getTimeDifference(t1, t2)
{
	
}

function getScheduleName(si) {
	return schedulesList.getElementsByTagName("Schedule")[si].getAttributeNode("Name").nodeValue;
}
function countOfSchedules() {
	count = schedulesList.getElementsByTagName("Schedule").length;
	return count;
}
function getClassName(si, ci) {
	return schedulesList.getElementsByTagName("Schedule")[si].getElementsByTagName("Class")[ci].getAttributeNode("Name").nodeValue;
}
function getClassBegin(si, ci) {
	return schedulesList.getElementsByTagName("Schedule")[si].getElementsByTagName("Class")[ci].getAttributeNode("Begin").nodeValue;
}
function getClassEnd(si, ci) {
	return schedulesList.getElementsByTagName("Schedule")[si].getElementsByTagName("Class")[ci].getAttributeNode("End").nodeValue;
}
function countOfClasses(si) {
	count = schedulesList.getElementsByTagName("Schedule")[si].getElementsByTagName("Class").length;
	return count;
}