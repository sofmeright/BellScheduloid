function getTimeRemainStandard()
{
	var date = new Date ( );
	var h = date.getHours ( );
	var m = date.getMinutes ( );
	var s = date.getSeconds ( );
	
	var periodfound = 0;
	while(periodfound == 0)
	{
		if (getClassBeginDate())
		periodfound = 1;
	}
	var timeOfDay;
	if (h < 12) {
		timeOfDay = "AM";
	} else {
		h -= 12;
		timeOfDay = "PM";
	}
	// Convert an hours component of "0" to "12"
	if (h == 0 ) { h = 12; }
	// Pad the hours, minutes, and seconds with leading zeros, if required.
	h = ( h < 10 ? "0" : "" ) + h;
	m = ( m < 10 ? "0" : "" ) + m;
	s = ( s < 10 ? "0" : "" ) + s;
	return h + ":" + m + ":" + s + " " + timeOfDay;
}
function isT1BeforeT2(time1, time2)
{
	comparable1 = time1.getHours() * 60 * 60 + time1.getMinutes() * 60 + time1.getSeconds();
	comparable2 = time2.getHours() * 60 * 60 + time2.getMinutes() * 60 + time2.getSeconds();
	if (comparable1 > comparable2)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
function getClassBeginDate(si, pi)
{
	return new Date(Date.parse("T" + document.getElementById("s" + si + "p" + pi + "-Begin").innerHTML));
}